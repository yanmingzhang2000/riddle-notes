import{c as e,j as t,R as o,S as r}from"./index-BoSVo4Qj.js";import"./schema-Cl-K63GW.js";e.createRoot(document.getElementById("root")).render(t.jsx(o.StrictMode,{children:t.jsx(r,{})}));
